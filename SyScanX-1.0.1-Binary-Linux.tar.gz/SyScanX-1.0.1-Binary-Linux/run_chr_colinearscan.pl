use strict;

print "command:  perl this_script.pl blast_file e-value score hitnum querygff sbjctgff pos_or_order is_or_not_cdsvchr fold_name\r\n";

my $outdir = "pair/".$ARGV[8].".pairs";
my $pairfold = -e "pair";
if(!$pairfold){system("mkdir pair");}
my $outdirfold = -e $outdir;
if(!$outdirfold){system("mkdir $outdir");}
system("rm -rf ".$outdir."/*");

my $querygenegff = $ARGV[4]; ### for gne positions
open(QGFF, $querygenegff) or die "cannot open $querygenegff due to $!\n";

my %querygene2pos;
my %querygene2order;
my %querygene2chr;
my %querychr2plen;
my %querychr2olen;
my $geneNumOnAchr;
my $lastchr = "";
while(<QGFF>)
{
  my @a = split("\t", $_);
  
  if($a[0] eq $lastchr)
  {
    $geneNumOnAchr ++;
  }
  else
  {
    $geneNumOnAchr = 1;
  }
  $querygene2order{$a[1]}=$geneNumOnAchr;
  $querygene2pos{$a[1]} = $a[2];
  my $chr = $a[0];
  $querygene2chr{$a[1]} = $chr;


  if($querychr2olen{$a[0]} !~ /^\d/)
  {
     $querychr2olen{$a[0]} = $geneNumOnAchr;
  }
  elsif($querychr2olen{$a[0]} < $geneNumOnAchr)
  {
     $querychr2olen{$a[0]} = $geneNumOnAchr;
  }

  if($querychr2plen{$a[0]} !~ /^\d/)
  {
     $querychr2plen{$a[0]} = $a[2];
  }
  elsif($querychr2plen{$a[0]} < $a[2])
  {
     $querychr2plen{$a[0]} = $a[2];
  }
  $lastchr = $chr;
}

my $sbjctgenegff = $ARGV[5]; ### for gne positions
open(SGFF, $sbjctgenegff) or die "cannot open $sbjctgenegff due to $!\n";

my %sbjctgene2pos;
my %sbjctgene2order;
my %sbjctgene2chr;
my %sbjctchr2plen;
my %sbjctchr2olen;
   $geneNumOnAchr = 0;
   $lastchr = "";
while(<SGFF>)
{
  my @a = split("\t", $_);
  
  if($a[0] eq $lastchr)
  {
    $geneNumOnAchr ++;
  }
  else
  {
    $geneNumOnAchr = 1;
  }
  $sbjctgene2order{$a[1]}=$geneNumOnAchr;
  $sbjctgene2pos{$a[1]} = $a[2];
  my $chr = $a[0];
  $sbjctgene2chr{$a[1]} = $chr;


  if($sbjctchr2olen{$a[0]} !~ /^\d/)
  {
     $sbjctchr2olen{$a[0]} = $geneNumOnAchr;
  }
  elsif($sbjctchr2olen{$a[0]} < $geneNumOnAchr)
  {
     $sbjctchr2olen{$a[0]} = $geneNumOnAchr;
  }

  if($sbjctchr2plen{$a[0]} !~ /^\d/)
  {
     $sbjctchr2plen{$a[0]} = $a[2];
  }
  elsif($sbjctchr2plen{$a[0]} < $a[2])
  {
     $sbjctchr2plen{$a[0]} = $a[2];
  }
  $lastchr = $chr;
}



my $input = $ARGV[0]; #input blast result files

open(IN, $input) or die "cannnot open the input file $input due to $!.\n";

my $subjctnum = 0;
my $query = "";
my $lastquery = "";
my $lastsubjct= "";
my $hitnum = 1;

while(<IN>)
{
   my @array = split(/\s+/, $_);
   
   if($array[0] eq $lastquery && $array[1] eq $lastsubjct){next;} # subhit regions were overlooked
   if($array[0] eq $array[1]){next;} # the same genes hit were overlooked


   if($array[11] < $ARGV[2]){next;} # the blast score for the longest hit segment
   if($array[10] > $ARGV[1]){next;} # the blast e-value
     
   if($array[0] eq $lastquery)
   {
      if($hitnum >= $ARGV[3]){next;}
      $hitnum ++;
   }
   else{$hitnum = 1;}

   my $querygene = $array[0];
   my $sbjctgene = $array[1];

   if(exists $querygene2chr{$querygene} && exists $sbjctgene2chr{$sbjctgene})
   {
   
   my $querychr = $querygene2chr{$querygene};   
   my $sbjctchr = $sbjctgene2chr{$sbjctgene};

   my $querypos="";
   my $sbjctpos="";
   if($ARGV[6] eq "pos")
   {
      $querypos = $querygene2pos{$querygene};
      $sbjctpos = $sbjctgene2pos{$sbjctgene};
   }
   else
   {
      $querypos = $querygene2order{$querygene};
      $sbjctpos = $sbjctgene2order{$sbjctgene};
   }
   
   if($ARGV[7] eq "y")
   { $sbjctpos = $array[8]; }

   #my $species1 = substr($query, 0, 2);
   ####  my $species2 = substr($sbjct, 0, 2);
  # my $species2 = "Ga";

  # if($species1 eq $species2 && $chr1 > $chr2){next;}
  # if($species1 eq $species2 && $chr1 eq $chr2 && abs($pos1 - $pos2) < 20){next;}
  
   my $color;
   if($hitnum eq 1) {$color = "primary";}
   elsif($hitnum eq 2){$color = "secondary";}
   else{$color = "thirdary";}

   my $direction = 1;
   if($array[8] > $array[9]){$direction = -1;}

#print $hitnum."\n";
   $lastquery = $array[0];
   $lastsubjct= $array[1];

   open(OUT, ">>".$outdir."/".join(".", "query.".$querychr, "vs.sbjct.".$sbjctchr).".pair") or die "cannot open output pair file due to $!.\n";

   if($querypos !~ /\d/ || $sbjctpos !~ /\d/){next;}
 
   print OUT $querygene."\t1\t".$querypos."\t".$sbjctgene."\t".$direction."\t".$sbjctpos."\n";
   }
}

close($input);

my $blockdir = "block/".$ARGV[8].".blocks";
my $blockfold = -e "block";
if(!$blockfold){system("mkdir block");}
my $blockdirfold = -e $blockdir;
if(!$blockdirfold){system("mkdir $blockdir");}
system("rm -rf ".$blockdir."/*");
my $Ext = "pair";
opendir(DH, $outdir) or die "Can't open: $!\n";
my @list = grep {/$Ext$/ && -f "$outdir/$_" } readdir(DH);
closedir(DH);
my $countnum=0;
foreach my $pairfile (@list)
{
   my @filename = split('\.',$pairfile);

   my $querychr = $filename[1];
   my $querychrnum = $querychr;
   $querychrnum =~ s/[^0-9]//g;
   $querychrnum = int($querychrnum);
#   if($querychrnum > 12 || $querychrnum == 0){next;}

   my $sbjctchr = $filename[4];
   my $sbjctchrnum = $sbjctchr;
   $sbjctchrnum =~ s/[^0-9]//g;
   $sbjctchrnum = int($sbjctchrnum);
#   if($sbjctchrnum > 10 || $sbjctchrnum == 0){next;}

   my $querychrlen;
   my $sbjctchrlen;
   if($ARGV[6] eq "pos" || $ARGV[7] eq "y")
   {
      system("echo ".$querychrnum."     ".$querychr2plen{$querychr}." > templenfile1.len");
      system("echo ".$sbjctchrnum."	".$sbjctchr2plen{$sbjctchr}." > templenfile2.len");
      print $sbjctchrnum."	".$sbjctchr2plen{$sbjctchr}."gj\n";
      $querychrlen = $querychr2plen{$querychr};
      $sbjctchrlen = $sbjctchr2plen{$sbjctchr};
   }
   elsif($ARGV[6] eq "order")
   {
      system("echo ".$querychrnum."     ".$querychr2olen{$querychr}." > templenfile1.len");
      system("echo ".$sbjctchrnum."	".$sbjctchr2olen{$sbjctchr}." > templenfile2.len");
      $querychrlen = $querychr2olen{$querychr};
      $sbjctchrlen = $sbjctchr2olen{$sbjctchr};
   }
#   system("rm *.purged");
   system("cp ".$outdir."/".$pairfile." ".$filename[0]."_".$filename[1]."_vs_".$filename[3]."_".$filename[4].".purged");
   $countnum = $countnum + 1;
   print($countnum."\r\nquery:".$querychrnum."     ".$querychrlen."	sbjct:".$sbjctchrnum."	".$sbjctchrlen."\r\n");
   system("ls *.purged");
   system("max_gap.pl --lenfile templenfile1.len --lenfile templenfile2.len --suffix purged > maxgap_result");
   system("rm templenfile1.len templenfile2.len");
   my @gap_result;
   open(GAP,"maxgap_result") or die "can not open maxgap_result\n";
   while(<GAP>)
   {@gap_result = split(/\s+/, $_);}
   print $gap_result[0]."````````````".$gap_result[1]."\n";
   close(GAP);
   system("blockscan -chr1len ".$querychrlen." -chr2len ".$sbjctchrlen." -mg1 ".$gap_result[0]." -mg2 ".$gap_result[1]." ".$filename[0]."_".$filename[1]."_vs_".$filename[3]."_".$filename[4].".purged > ".$blockdir."/".$filename[0].".".$filename[1].".".$filename[2].".".$filename[3].".".$filename[4].".blk");
   system("rm maxgap_result *.purged");
   
}
   #system("perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl ".$blockdir);
   system("perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl ".$blockdir." ".$ARGV[6]);
   system("cat ".$blockdir."/*.blk > block/".$ARGV[8].".blk.rr");
