#!/usr/bin/perl
use strict;

my $dir = $ARGV[0];

opendir (DIR, $dir) or die "Couldn't open directory, $!";
while (my $file = readdir DIR)
{
  print "$file\n";
  if($file =~ /rr/)
  {
    print "unlink $file\n"; 
    my $fullname = $dir."/".$file;
    print "the file is $fullname.\n";

    if (unlink($fullname) == 0) 
    {
    print "File deleted successfully.\n";
    }else 
    {
    print "File was not deleted.\n";
    }
  }
  if($file =~ /^\./){next;}
  remove_redundancy($file, $dir);

}
closedir DIR;

sub remove_redundancy()
{
   my $file = $_[0];
   my $dir = $_[1];
   my $outfile = $file.".rr";

   my @ssee = ();
   my $is2remover = 0;
   my @blocklines = ();

   open(IN, $dir."/".$file) or die "cannot open $file due to $!.\n";
   open(OUT, ">".$dir."/".$outfile) or die "cannot open $outfile due to $!.\n";

   my $num = -1;
   my ($id1, $id2, $pos1, $pos2, $orient);
   my ($start1, $start2, $end1, $end2);
   my ($sp1, $sp2);

   while(<IN>)
   {
      if($_ =~ /^[+\s]/){print OUT $_; next;}
      if($_ =~ /^t/){$num++; print OUT $_; next;}
      if($_ =~ /^>/)
      {
        $end1 = $pos1; 
        $end2 = $pos2; 

        my $is2add = 1;        
        my $reason = "";
        for(my $i=0; $i<=$#ssee; $i++)
        {
           if($sp1 eq $sp2)
           {
             my $isself = isself($start1, $start2, $end1, $end2);
             if($isself eq 1){$is2add = 0; $reason = "self homologous"; last;}
           }
           my ($bstart1, $bstart2, $bend1, $bend2) = split(/\t/, $ssee[$i]);
           my $isoverlap = isoverlap($start1, $start2, $end1, $end2, $bstart1, $bstart2, $bend1, $bend2);
           if($isoverlap eq 1)
           {
              $is2add = 0; $reason = "overlap with block $i+1th"; last;
           }
        }
        
        if($is2add eq 1)
        {
             $ssee[$#ssee+1] = join("\t", $start1, $start2, $end1, $end2);
             for(my $n =0; $n<=$#blocklines; $n++)
             {
                print OUT $blocklines[$n];
             }
        }
        print OUT $_;
        print OUT $reason."\n";

        @blocklines = ();
        $num = -1;
     
        next;
      }
      
      $blocklines[$#blocklines+1] = $_;
      $_ =~ s/[\n\r]//;
      ($id1, $pos1, $id2, $pos2, $orient) = split(/\s/, $_);
      if($#blocklines eq 0)
      {
       $sp1 = substr($id1, 0, 2);
       $sp2 = substr($id2, 0, 2);
       $start1 = $pos1;
       $start2 = $pos2;
      }
   }
}

sub isself()
{
   my $start1 = min($_[0], $_[2]);
   my $end1   = max($_[0], $_[2]);
   my $start2 = min($_[1], $_[3]);
   my $end2   = max($_[1], $_[3]);

   if(abs($start1-$start2) < 30 && abs($end2-$end1) < 50)
   {
     return 1;
   }
   else
   {
     return 0;
   }
}

sub isoverlap()
{
   my $s1 = min($_[0], $_[2]);
   my $e1 = max($_[0], $_[2]);
   my $s2 = min($_[1], $_[3]);
   my $e2 = max($_[1], $_[3]);

   my $bs1 = min($_[4], $_[6]);
   my $be1 = max($_[4], $_[6]);
   my $bs2 = min($_[5], $_[7]);
   my $be2 = max($_[5], $_[7]);

   if($s1 >= $bs1-30 && $e1 <= $be1+30 && $s2 >= $bs2-50 && $e2 <= $be2+50)
   {
      return 1;
   }
   else
   {
      return 0;
   }
}
sub min(){if($_[0]<$_[1]){return $_[0];}else{return $_[1];}}
sub max(){if($_[0]>$_[1]){return $_[0];}else{return $_[1];}}