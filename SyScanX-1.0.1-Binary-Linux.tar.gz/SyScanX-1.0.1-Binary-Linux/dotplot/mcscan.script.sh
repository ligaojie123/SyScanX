#!/bin/bash

cut -f 1,2,11 ../pro_gff_data/os_os.newid.blast > os_os.blast.unfiltered
cut -f 1,2,11 ../pro_gff_data/os_sb.newid.blast > os_sb.blast.unfiltered
cut -f 1,2,11 ../pro_gff_data/os_zm.newid.blast > os_zm.blast.unfiltered
cut -f 1,2,11 ../pro_gff_data/sb_zm.newid.blast > sb_zm.blast.unfiltered
cut -f 1,2,11 ../pro_gff_data/sb_sb.newid.blast > sb_sb.blast.unfiltered
cut -f 1,2,11 ../pro_gff_data/zm_zm.newid.blast > zm_zm.blast.unfiltered

python tanghaibao-mcscan-4cfe0f5/filter_blast.py os_os.blast.unfiltered os_os.mcscan.blast
python tanghaibao-mcscan-4cfe0f5/filter_blast.py os_sb.blast.unfiltered os_sb.mcscan.blast
python tanghaibao-mcscan-4cfe0f5/filter_blast.py os_zm.blast.unfiltered os_zm.mcscan.blast
python tanghaibao-mcscan-4cfe0f5/filter_blast.py sb_sb.blast.unfiltered sb_sb.mcscan.blast
python tanghaibao-mcscan-4cfe0f5/filter_blast.py sb_zm.blast.unfiltered sb_zm.mcscan.blast
python tanghaibao-mcscan-4cfe0f5/filter_blast.py zm_zm.blast.unfiltered zm_zm.mcscan.blast

cat ../pro_gff_data/os.newid.bed ../pro_gff_data/os.newid.bed > os_os.mcscan.bed
cat ../pro_gff_data/os.newid.bed ../pro_gff_data/sb.newid.bed > os_sb.mcscan.bed
cat ../pro_gff_data/os.newid.bed ../pro_gff_data/zm.newid.bed > os_zm.mcscan.bed
cat ../pro_gff_data/sb.newid.bed ../pro_gff_data/sb.newid.bed > sb_sb.mcscan.bed
cat ../pro_gff_data/sb.newid.bed ../pro_gff_data/zm.newid.bed > sb_zm.mcscan.bed
cat ../pro_gff_data/zm.newid.bed ../pro_gff_data/zm.newid.bed > zm_zm.mcscan.bed

tanghaibao-mcscan-4cfe0f5/mcscan os_os.mcscan -a
tanghaibao-mcscan-4cfe0f5/mcscan os_sb.mcscan -a
tanghaibao-mcscan-4cfe0f5/mcscan os_zm.mcscan -a
tanghaibao-mcscan-4cfe0f5/mcscan sb_sb.mcscan -a
tanghaibao-mcscan-4cfe0f5/mcscan sb_zm.mcscan -a
tanghaibao-mcscan-4cfe0f5/mcscan zm_zm.mcscan -a

perl ../mcscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 ../pro_gff_data/os.newid.gff ../pro_gff_data/os.newid.gff os_os.mcscan.aligns order Os Os 0 1 5

perl ../mcscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 ../pro_gff_data/os.newid.gff ../pro_gff_data/sb.newid.gff os_sb.mcscan.aligns order Os Sb 0 1 5

perl ../mcscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 1_2_3_4_5_6_7_8_9_10 ../pro_gff_data/os.newid.gff ../pro_gff_data/zm.newid.gff os_zm.mcscan.aligns order Os Zm 0 1 5

perl ../mcscan2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 ../pro_gff_data/sb.newid.gff ../pro_gff_data/sb.newid.gff sb_sb.mcscan.aligns order Sb Sb 0 1 5

perl ../mcscan2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 1_2_3_4_5_6_7_8_9_10 ../pro_gff_data/sb.newid.gff ../pro_gff_data/zm.newid.gff sb_zm.mcscan.aligns order Sb Zm 0 1 5

perl ../mcscan2dotplot.pl 1_2_3_4_5_6_7_8_9_10 1_2_3_4_5_6_7_8_9_10 ../pro_gff_data/zm.newid.gff ../pro_gff_data/zm.newid.gff zm_zm.mcscan.aligns order Zm Zm 0 1 5

perl mcscan2dotplot.pl 1_2_3_4_5_6_7_8_9_10_11_12 01_02_03_04_05_06_07_08_09_10 Os.newid.gff Sb.newid.gff xyz.aligns order Os Sb 0 1 5
#perl ../mcscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 ../pro_gff_data/os.newid.gff ../pro_gff_data/os.newid.gff os_os.mcscan.aligns pos Os Os
#perl ../mcscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 ../pro_gff_data/os.newid.gff ../pro_gff_data/sb.newid.gff os_sb.mcscan.aligns pos Os Sb
#perl ../mcscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 1_2_3_4_5_6_7_8_9_10 ../pro_gff_data/os.newid.gff ../pro_gff_data/zm.newid.gff os_zm.mcscan.aligns pos Os Zm
#perl ../mcscan2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 ../pro_gff_data/sb.newid.gff ../pro_gff_data/sb.newid.gff sb_sb.mcscan.aligns pos Sb Sb
#perl ../mcscan2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 1_2_3_4_5_6_7_8_9_10 ../pro_gff_data/sb.newid.gff ../pro_gff_data/zm.newid.gff sb_zm.mcscan.aligns pos Sb Zm
#perl ../mcscan2dotplot.pl 1_2_3_4_5_6_7_8_9_10 1_2_3_4_5_6_7_8_9_10 ../pro_gff_data/zm.newid.gff ../pro_gff_data/zm.newid.gff zm_zm.mcscan.aligns pos Zm Zm
