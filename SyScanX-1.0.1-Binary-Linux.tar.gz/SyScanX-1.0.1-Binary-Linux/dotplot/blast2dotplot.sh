#!/bin/bash

perl ../blast2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 os.newid.gff os.newid.gff os_os.newid.blast pos Os Os 1e-10 0 30
perl ../blast2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 os.newid.gff sb.newid.gff os_sb.newid.blast pos Os Sb 1e-10 0 30
perl ../blast2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 1_2_3_4_5_6_7_8_9_10 os.newid.gff zm.newid.gff os_zm.newid.blast pos Os Zm 1e-10 0 30
perl ../blast2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 sb.newid.gff sb.newid.gff sb_sb.newid.blast pos Sb Sb 1e-10 0 30
perl ../blast2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 1_2_3_4_5_6_7_8_9_10 sb.newid.gff zm.newid.gff sb_zm.newid.blast pos Sb Zm 1e-10 0 30
perl ../blast2dotplot.pl 1_2_3_4_5_6_7_8_9_10 1_2_3_4_5_6_7_8_9_10 zm.newid.gff zm.newid.gff zm_zm.newid.blast pos Zm Zm 1e-10 0 30

perl blast_svg_dotplot.pl Sb01_Sb02_Sb03_Sb04_Sb05_Sb06_Sb07_Sb08_Sb09_Sb10 Os1_Os2_Os3_Os4_Os5_Os6_Os7_Os8_Os9_Os10_Os11_Os12 Sb.newid.gff Os.newid.gff Sb.Os.prot.blast order Sb Os 1e-5 0 5

perl blast_svg_dotplot.pl Sb01_Sb02_Sb03_Sb04_Sb05_Sb06_Sb07_Sb08_Sb09_Sb10 Sb01_Sb02_Sb03_Sb04_Sb05_Sb06_Sb07_Sb08_Sb09_Sb10 Sb.newid.gff Sb.newid.gff Sb.Sb.prot.blast order Sb Sb 1e-5 0 5

perl blast_svg_dotplot.pl Sb01_Sb02_Sb03_Sb04_Sb05_Sb06_Sb07_Sb08_Sb09_Sb10 Os1_Os2_Os3_Os4_Os5_Os6_Os7_Os8_Os9_Os10_Os11_Os12 Sb.newid.gff Os.newid.gff Sb.Os.prot.blast order Sb Os 1e-5 0 5

perl blast_svg_dotplot.pl Zm1_Zm2_Zm3_Zm4_Zm5_Zm6_Zm7_Zm8_Zm9_Zm10 Zm1_Zm2_Zm3_Zm4_Zm5_Zm6_Zm7_Zm8_Zm9_Zm10 Zm.newid.gff Zm.newid.gff Zm.Zm.prot.blast order Zm Zm 1e-5 0 5