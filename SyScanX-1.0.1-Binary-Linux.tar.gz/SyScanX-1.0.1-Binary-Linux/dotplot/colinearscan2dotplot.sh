#!/bin/bash

perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl block/Os_Os.blocks/
cat block/Os_Os.blocks/*.rr > block/Os_Os.blk.rr
perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl block/Os_Sb.blocks/
cat block/Os_Sb.blocks/*.rr > block/Os_Sb.blk.rr
perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl block/Os_Zm.blocks/
cat block/Os_Zm.blocks/*.rr > block/Os_Zm.blk.rr
perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl block/Sb_Sb.blocks/
cat block/Sb_Sb.blocks/*.rr > block/Sb_Sb.blk.rr
perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl block/Sb_Zm.blocks/
cat block/Sb_Zm.blocks/*.rr > block/Sb_Zm.blk.rr
perl remove.redundancy.in.colinearscan.blocks.by.geneorder.pl block/Zm_Zm.blocks/
cat block/Zm_Zm.blocks/*.rr > block/Zm_Zm.blk.rr

perl ../colinearscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 os.newid.gff os.newid.gff block/Os_Os.blk.rr pos Os Os 0.01 20
perl ../colinearscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 os.newid.gff sb.newid.gff block/Os_Sb.blk.rr pos Os Sb 0.01 20
perl ../colinearscan2dotplot.pl Chr1_Chr2_Chr3_Chr4_Chr5_Chr6_Chr7_Chr8_Chr9_Chr10_Chr11_Chr12 1_2_3_4_5_6_7_8_9_10 os.newid.gff zm.newid.gff block/Os_Zm.blk.rr pos Os Zm 0.01 20
perl ../colinearscan2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 sb.newid.gff sb.newid.gff block/Sb_Sb.blk.rr pos Sb Sb 0.01 20
perl ../colinearscan2dotplot.pl Chr01_Chr02_Chr03_Chr04_Chr05_Chr06_Chr07_Chr08_Chr09_Chr10 1_2_3_4_5_6_7_8_9_10 sb.newid.gff zm.newid.gff block/Sb_Zm.blk.rr pos Sb Zm 0.01 20
perl ../colinearscan2dotplot.pl 1_2_3_4_5_6_7_8_9_10 1_2_3_4_5_6_7_8_9_10 zm.newid.gff zm.newid.gff block/Zm_Zm.blk.rr pos Zm Zm 0.01 20
###
perl ../colinearscan2dotplot.pl 1_2_3_4_5_6_7_8_9_10_11_12 01_02_03_04_05_06_07_08_09_10 Os.newid.gff Sb.newid.gff block/Os_Sb.blk pos Os Sb 0.01 20
perl colinearscan2dotplot.pl 1_2_3_4_5_6_7_8_9_10_11_12 01_02_03_04_05_06_07_08_09_10 Os.newid.gff Sb.newid.gff block/Os_Sb.blk pos Os Sb 0.01 20